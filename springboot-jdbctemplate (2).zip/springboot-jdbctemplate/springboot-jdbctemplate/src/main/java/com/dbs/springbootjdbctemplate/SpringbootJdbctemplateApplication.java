package com.dbs.springbootjdbctemplate;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.dbs.springbootjdbctemplate.dto.Employee;
import com.dbs.springbootjdbctemplate.service.EmployeeService;

@SpringBootApplication
public class SpringbootJdbctemplateApplication {

	public static void main(String[] args) {
	ApplicationContext  applicationContext =SpringApplication.run(SpringbootJdbctemplateApplication.class, args);
	DataSource dataSource = applicationContext.getBean(DataSource.class);
	System.out.println(dataSource!=null);
	EmployeeService employeeService = applicationContext.getBean(EmployeeService.class);
	Employee employee = new Employee(1235,"ch","sandeep",1200.50f);
	Employee employee2 = employeeService.createEmployee(employee);
	System.out.println(employee2);
	}

}

package com.dbs.projectpayment.dto;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Entity
@Table(name="sender")
@NoArgsConstructor
@AllArgsConstructor
public class Sender {
	
	
	private String sender_id;
	
	private String sender_name;
	
	private int clear_balance;
	
	private char overdraft;
	
}

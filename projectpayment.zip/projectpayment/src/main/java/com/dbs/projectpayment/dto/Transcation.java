package com.dbs.projectpayment.dto;

public class Transcation {

}

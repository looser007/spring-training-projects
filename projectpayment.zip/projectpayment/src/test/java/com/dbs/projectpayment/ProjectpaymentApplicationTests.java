package com.dbs.projectpayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectpaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.dbs.springsecuritys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecuritysApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecuritysApplication.class, args);
	}

}

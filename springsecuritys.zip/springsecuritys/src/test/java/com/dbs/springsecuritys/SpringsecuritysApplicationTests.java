package com.dbs.springsecuritys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecuritysApplicationTests {

	@Test
	void contextLoads() {
	}

}
